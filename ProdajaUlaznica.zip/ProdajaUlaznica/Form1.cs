﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProdajaUlaznica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnUlaznica_Click(object sender, EventArgs e)
        {
            KupnjaUlaznice f2 = new KupnjaUlaznice();
            f2.ShowDialog();
        }
    }
}
